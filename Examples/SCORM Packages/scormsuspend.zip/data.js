var data = [{
  "text": "What color is Pikachu?",
  "answers": ["Red", "Yellow","Green","Blue"],
  "correct": "Yellow",
  "response": ""
},

{
  "text": "What color is Squirtle?",
  "answers": ["Red", "Yellow","Green","Blue"],
  "correct": "Blue",
  "response": ""
},

{
  "text": "What color is Charmander?",
  "answers": ["Red", "Yellow","Green","Blue"],
  "correct": "Red",
  "response": ""
},

{
  "text": "What color is Bulbasaur?",
  "answers": ["Red", "Yellow","Green","Blue"],
  "correct": "Green",
  "response": ""
}]
